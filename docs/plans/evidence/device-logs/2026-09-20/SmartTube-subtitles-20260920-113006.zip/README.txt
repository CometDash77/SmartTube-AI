SmartTube local subtitle export / SmartTube 本地字幕导出
generatedAt=2026-09-20 11:30:06
sourceLanguage=en
sourceMime=text/vtt
targetLanguage=en
frames=520
items=520
translatedItems=0
failedItems=0
notAttemptedItems=520
missingItems=520
coveragePercent=0

Missing translations fall back to the original text. / 缺失译文处使用原文回退。
Only data the app had already obtained is exported; this export translates nothing and calls no AI service. / 本导出只使用应用已取得的数据，不会翻译任何内容，也不会调用 AI 服务。
The translation cache is bounded (2000 entries / 2097152 bytes), so older translations may have been evicted. This is not a full-video translation. / 译文缓存有容量上限（2000 条 / 2097152 字节），较早的译文可能已被淘汰；这不代表整部视频已翻译。
Timecodes reuse the original timeline; the last cue's end is an estimate because the source has no known end. / 时间码沿用原始时间轴；最后一条字幕的结束时间为估算值，因为来源没有已知结束时间。

Files: original.srt = original; translated.srt = translation with original fallback; bilingual.srt = original above translation; untranslated.srt = only the cues still without a translation; translation-status.txt = per-cue state (TRANSLATED / FAILED / NOT_ATTEMPTED).
This export does not need the AI switch or an API key, and works with an interrupted or failed translation run. / 本导出不需要 AI 开关或 API Key，翻译被中断或失败时也能导出。
No translation was available at export time. / 导出时没有可用的译文。
